# -*- coding: utf-8 -*-

import pandas as pd
import numpy as np
import time
import re  

    
def getmax(l):
    max_d=[]
    for i in l:
        if i == []:
            tmp=-1
        else:
            tmp=max(i)
        max_d.append(tmp)
    return max_d

def get_mean(l):
    mean=[]
    for i in l:
        if i==[float('inf')]:
            tmp=1800
        else:
            i=np.array(i)
            tmp=np.mean(i)/60
            tmp = -round(tmp, 2)
        mean.append(tmp)
    return mean



encoding='utf-8'
#encoding = get_encoding('r3.csv')
r3=pd.read_csv('file/r3.csv',encoding=encoding)
r3.rename(columns={'A_follower_cnt':'A_follower_cnt_3','A_time':'A_time_3','A_voteup_cnt':'A_voteup_cnt_3','Answer_cnt':'Answer_cnt_3','Q_follower_cnt':'Q_follower_cnt_3','Time':'Time_3','Visit_cnt':'Visit_cnt_3'},inplace=True)
#encoding = get_encoding('r4.csv')
r4=pd.read_csv('file/r4.csv',encoding=encoding)

#encoding = get_encoding('r5.csv')
r5=pd.read_csv('file/t5.csv',encoding=encoding)
r5.rename(columns={'A_follower_cnt':'A_follower_cnt_5','A_time':'A_time_5','A_voteup_cnt':'A_voteup_cnt_5','Answer_cnt':'Answer_cnt_5','Q_follower_cnt':'Q_follower_cnt_5','Time':'Time_5','Visit_cnt':'Visit_cnt_5'},inplace=True)

#-------------------------------------------------------------round 3
afollow_cnt_3=list(r3['A_follower_cnt_3'])
afollow_cnt_2=list(r3['A_follower_cnt_2'])
afollow_cnt_1=list(r3['A_follower_cnt_1'])

afc1=[]
for i in afollow_cnt_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc1.append(tmp)
r3['A_follower_cnt_1']=afc1
afc2=[]
for i in afollow_cnt_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc2.append(tmp)
r3['A_follower_cnt_2']=afc2
afc3=[]
for i in afollow_cnt_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc3.append(tmp)
r3['A_follower_cnt_3']=afc3

at_3=list(r3['A_time_3'])
at_2=list(r3['A_time_2'])
at_1=list(r3['A_time_1'])

at1=[]
for i in at_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at1.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at1.append(tmp)
r3['A_time_1']=get_mean(at1)
at2=[]
for i in at_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at2.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at2.append(tmp)
r3['A_time_2']=get_mean(at2)
at3=[]
for i in at_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at3.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at3.append(tmp)
r3['A_time_3']=get_mean(at3)


av_3=list(r3['A_voteup_cnt_3'])
av_2=list(r3['A_voteup_cnt_2'])
av_1=list(r3['A_voteup_cnt_1'])

av1=[]
for i in av_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av1.append(tmp)
r3['A_voteup_cnt_1']=av1
av2=[]
for i in av_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av2.append(tmp)
r3['A_voteup_cnt_2']=av2
av3=[]
for i in av_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av3.append(tmp)
r3['A_voteup_cnt_3']=av3


#------------------------------------------------------------------round 4
afollow_cnt_4=list(r4['A_follower_cnt_4'])
afollow_cnt_3=list(r4['A_follower_cnt_3'])
afollow_cnt_2=list(r4['A_follower_cnt_2'])
afollow_cnt_1=list(r4['A_follower_cnt_1'])

afc1=[]
for i in afollow_cnt_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc1.append(tmp)
r4['A_follower_cnt_1']=afc1
afc2=[]
for i in afollow_cnt_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc2.append(tmp)
r4['A_follower_cnt_2']=afc2
afc3=[]
for i in afollow_cnt_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc3.append(tmp)
r4['A_follower_cnt_3']=afc3
afc4=[]
for i in afollow_cnt_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc4.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc4.append(tmp)
r4['A_follower_cnt_4']=afc4

at_4=list(r4['A_time_4'])
at_3=list(r4['A_time_3'])
at_2=list(r4['A_time_2'])
at_1=list(r4['A_time_1'])

at1=[]
for i in at_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at1.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at1.append(tmp)
r4['A_time_1']=get_mean(at1)
at2=[]
for i in at_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at2.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at2.append(tmp)
r4['A_time_2']=get_mean(at2)
at3=[]
for i in at_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at3.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at3.append(tmp)
r4['A_time_3']=get_mean(at3)
at4=[]
for i in at_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at4.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at4.append(tmp)
r4['A_time_4']=get_mean(at4)

av_4=list(r4['A_voteup_cnt_4'])
av_3=list(r4['A_voteup_cnt_3'])
av_2=list(r4['A_voteup_cnt_2'])
av_1=list(r4['A_voteup_cnt_1'])

av1=[]
for i in av_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av1.append(tmp)
r4['A_voteup_cnt_1']=av1
av2=[]
for i in av_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av2.append(tmp)
r4['A_voteup_cnt_2']=av2
av3=[]
for i in av_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av3.append(tmp)
r4['A_voteup_cnt_3']=av3
av4=[]
for i in av_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av4.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av4.append(tmp)
r4['A_voteup_cnt_4']=av4


#---------------------------------------------------------------round 5
afollow_cnt_5=list(r5['A_follower_cnt_5'])
afollow_cnt_4=list(r5['A_follower_cnt_4'])
afollow_cnt_3=list(r5['A_follower_cnt_3'])
afollow_cnt_2=list(r5['A_follower_cnt_2'])
afollow_cnt_1=list(r5['A_follower_cnt_1'])

afc1=[]
for i in afollow_cnt_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc1.append(tmp)
r5['A_follower_cnt_1']=afc1
afc2=[]
for i in afollow_cnt_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc2.append(tmp)
r5['A_follower_cnt_2']=afc2
afc3=[]
for i in afollow_cnt_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc3.append(tmp)
r5['A_follower_cnt_3']=afc3
afc4=[]
for i in afollow_cnt_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc4.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc4.append(tmp)
r5['A_follower_cnt_4']=afc4
afc5=[]
for i in afollow_cnt_5:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        afc5.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        afc5.append(tmp)
r5['A_follower_cnt_5']=afc5

at_5=list(r5['A_time_5'])
at_4=list(r5['A_time_4'])
at_3=list(r5['A_time_3'])
at_2=list(r5['A_time_2'])
at_1=list(r5['A_time_1'])

at1=[]
for i in at_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at1.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at1.append(tmp)
r5['A_time_1']=get_mean(at1)
at2=[]
for i in at_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at2.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at2.append(tmp)
r5['A_time_2']=get_mean(at2)
at3=[]
for i in at_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at3.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at3.append(tmp)
r5['A_time_3']=get_mean(at3)
at4=[]
for i in at_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at4.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at4.append(tmp)
r5['A_time_4']=get_mean(at4)
at5=[]
for i in at_5:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0 or len(i.split(','))==1:
        at5.append([float('inf')])
    else:
        tmp=[]
        temp=i.split(',')
        initial=temp[0]
        temp.remove(initial)
        for j in temp:
            tmp.append(int(j)-int(initial))
            initial=j
        at5.append(tmp)
r5['A_time_5']=get_mean(at5)

av_5=list(r5['A_voteup_cnt_5'])
av_4=list(r5['A_voteup_cnt_4'])
av_3=list(r5['A_voteup_cnt_3'])
av_2=list(r5['A_voteup_cnt_2'])
av_1=list(r5['A_voteup_cnt_1'])

av1=[]
for i in av_1:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av1.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av1.append(tmp)
r5['A_voteup_cnt_1']=av1
av2=[]
for i in av_2:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av2.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av2.append(tmp)
r5['A_voteup_cnt_2']=av2
av3=[]
for i in av_3:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av3.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av3.append(tmp)
r5['A_voteup_cnt_3']=av3
av4=[]
for i in av_4:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av4.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av4.append(tmp)
r5['A_voteup_cnt_4']=av4
av5=[]
for i in av_5:
    i=i.translate(str.maketrans('','','['))
    i=i.translate(str.maketrans('','',']'))
    if len(i)==0:
        av5.append([])
    else:
        tmp=[]
        temp=i.split(',')
        for j in temp:
            tmp.append(int(j))
        av5.append(tmp)
r5['A_voteup_cnt_5']=av5

#---------------------------------------------------------------------------------------


#r3
r3_time=r3[['q_id','Time_1','Time_2','Time_3']]
r3_visit_cnt=r3[['q_id','Visit_cnt_1','Visit_cnt_2','Visit_cnt_3']]
r3_ans_cnt=r3[['q_id','Answer_cnt_1','Answer_cnt_2','Answer_cnt_3']]
r3_q_fol_cnt=r3[['q_id','Q_follower_cnt_1','Q_follower_cnt_2','Q_follower_cnt_3']] 
r3_a_fol_cnt=r3[['q_id','A_follower_cnt_1','A_follower_cnt_2','A_follower_cnt_3']]
r3_a_vote_cnt=r3[['q_id','A_voteup_cnt_1','A_voteup_cnt_2','A_voteup_cnt_3']]
r3_ans_time=r3[['q_id','A_time_1','A_time_2','A_time_3']]
r3_info=r3[['q_id','Tag']]
#r4
r4_time=r4[['q_id','Time_1','Time_2','Time_3','Time_4']]
r4_visit_cnt=r4[['q_id','Visit_cnt_1','Visit_cnt_2','Visit_cnt_3','Visit_cnt_4']]
r4_ans_cnt=r4[['q_id','Answer_cnt_1','Answer_cnt_2','Answer_cnt_3','Answer_cnt_4']]
r4_q_fol_cnt=r4[['q_id','Q_follower_cnt_1','Q_follower_cnt_2','Q_follower_cnt_3','Q_follower_cnt_4']]
r4_a_fol_cnt=r4[['q_id','A_follower_cnt_1','A_follower_cnt_2','A_follower_cnt_3','A_follower_cnt_4']]
r4_a_vote_cnt=r4[['q_id','A_voteup_cnt_1','A_voteup_cnt_2','A_voteup_cnt_3','A_voteup_cnt_4']]
r4_ans_time=r4[['q_id','A_time_1','A_time_2','A_time_3','A_time_4']]
r4_info=r4[['q_id','Tag']]
#r5
r5_visit_cnt=r5[['q_id','Visit_cnt_1','Visit_cnt_2','Visit_cnt_3','Visit_cnt_4','Visit_cnt_5']]
r5_time=r5[['q_id','Time_1','Time_2','Time_3','Time_4','Time_5']]
r5_ans_cnt=r5[['q_id','Answer_cnt_1','Answer_cnt_2','Answer_cnt_3','Answer_cnt_4','Answer_cnt_5']]
r5_q_fol_cnt=r5[['q_id','Q_follower_cnt_1','Q_follower_cnt_2','Q_follower_cnt_3','Q_follower_cnt_4','Q_follower_cnt_5']]
r5_a_fol_cnt=r5[['q_id','A_follower_cnt_1','A_follower_cnt_2','A_follower_cnt_3','A_follower_cnt_4','A_follower_cnt_5']]
r5_a_vote_cnt=r5[['q_id','A_voteup_cnt_1','A_voteup_cnt_2','A_voteup_cnt_3','A_voteup_cnt_4','A_voteup_cnt_5']]
r5_ans_time=r5[['q_id','A_time_1','A_time_2','A_time_3','A_time_4','A_time_5']]
r5_info=r5[['q_id','Tag']]

#--------------------------------------------------------------------------------

#features3
d3=r3[['q_id']]
##1,6,11
l1=np.array(list(r3['Visit_cnt_1']))
l2=np.array(list(r3['Visit_cnt_2']))
l3=np.array(list(r3['Visit_cnt_3']))
a=list(l2-l1)
b=list(l3-l2)
l1=list(l1)
d3['1']=l1
d3['6']=a
d3['11']=b
##2,7,12
l1=np.array(list(r3['Answer_cnt_1']))
l2=np.array(list(r3['Answer_cnt_2']))
l3=np.array(list(r3['Answer_cnt_3']))
a=list(l2-l1)
b=list(l3-l2)
l1=list(l1)
d3['2']=l1
d3['7']=a
d3['12']=b
##3,8,13
l1=np.array(list(r3['Q_follower_cnt_1']))
l2=np.array(list(r3['Q_follower_cnt_2']))
l3=np.array(list(r3['Q_follower_cnt_3']))
a=list(l2-l1)
b=list(l3-l2)
l1=list(l1)
d3['3']=l1
d3['8']=a
d3['13']=b
##4,9,14
l1=list(r3['A_follower_cnt_1'])
l2=list(r3['A_follower_cnt_2'])
l3=list(r3['A_follower_cnt_3'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
d3['4']=max_1
d3['9']=max_2
d3['14']=max_3
##5,10,15
l1=list(r3['A_voteup_cnt_1'])
l2=list(r3['A_voteup_cnt_2'])
l3=list(r3['A_voteup_cnt_3'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
d3['5']=max_1
d3['10']=max_2
d3['15']=max_3
##reorder
order=['q_id','1','2','3','4','5','6','7','8','9','10','11','12','13','14','15']
d3=d3[order]
d3['td1']=list(r3['A_time_1'])
d3['td2']=list(r3['A_time_2'])
d3['td3']=list(r3['A_time_3'])

#features4
d4=r4[['q_id']]
##1,6,11,16
l1=np.array(list(r4['Visit_cnt_1']))
l2=np.array(list(r4['Visit_cnt_2']))
l3=np.array(list(r4['Visit_cnt_3']))
l4=np.array(list(r4['Visit_cnt_4']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
l1=list(l1)
d4['1']=l1
d4['6']=a
d4['11']=b
d4['16']=c
##2,7,12,17
l1=np.array(list(r4['Answer_cnt_1']))
l2=np.array(list(r4['Answer_cnt_2']))
l3=np.array(list(r4['Answer_cnt_3']))
l4=np.array(list(r4['Answer_cnt_4']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
l1=list(l1)
d4['2']=l1
d4['7']=a
d4['12']=b
d4['17']=c
##3,8,13,18
l1=np.array(list(r4['Q_follower_cnt_1']))
l2=np.array(list(r4['Q_follower_cnt_2']))
l3=np.array(list(r4['Q_follower_cnt_3']))
l4=np.array(list(r4['Q_follower_cnt_4']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
l1=list(l1)
d4['3']=l1
d4['8']=a
d4['13']=b
d4['18']=c
##4,9,14,19
l1=list(r4['A_follower_cnt_1'])
l2=list(r4['A_follower_cnt_2'])
l3=list(r4['A_follower_cnt_3'])
l4=list(r4['A_follower_cnt_4'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
max_4=getmax(l4)
d4['4']=max_1
d4['9']=max_2
d4['14']=max_3
d4['19']=max_4
##5,10,15,20
l1=list(r4['A_voteup_cnt_1'])
l2=list(r4['A_voteup_cnt_2'])
l3=list(r4['A_voteup_cnt_3'])
l4=list(r4['A_voteup_cnt_4'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
max_4=getmax(l4)
d4['5']=max_1
d4['10']=max_2
d4['15']=max_3
d4['20']=max_4
##reorder
order+=['16','17','18','19','20']
d4=d4[order]
d4['td1']=list(r4['A_time_1'])
d4['td2']=list(r4['A_time_2'])
d4['td3']=list(r4['A_time_3'])
d4['td4']=list(r4['A_time_4'])

#feature 5
d5=r5[['q_id']]
##1,6,11,16,21
l1=np.array(list(r5['Visit_cnt_1']))
l2=np.array(list(r5['Visit_cnt_2']))
l3=np.array(list(r5['Visit_cnt_3']))
l4=np.array(list(r5['Visit_cnt_4']))
l5=np.array(list(r5['Visit_cnt_5']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
d=list(l5-l4)
l1=list(l1)
d5['1']=l1
d5['6']=a
d5['11']=b
d5['16']=c
d5['21']=d
##2,7,12,17,22
l1=np.array(list(r5['Answer_cnt_1']))
l2=np.array(list(r5['Answer_cnt_2']))
l3=np.array(list(r5['Answer_cnt_3']))
l4=np.array(list(r5['Answer_cnt_4']))
l5=np.array(list(r5['Answer_cnt_5']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
d=list(l5-l4)
l1=list(l1)
d5['2']=l1
d5['7']=a
d5['12']=b
d5['17']=c
d5['22']=d
##3,8,13,18,23
l1=np.array(list(r5['Q_follower_cnt_1']))
l2=np.array(list(r5['Q_follower_cnt_2']))
l3=np.array(list(r5['Q_follower_cnt_3']))
l4=np.array(list(r5['Q_follower_cnt_4']))
l5=np.array(list(r5['Q_follower_cnt_5']))
a=list(l2-l1)
b=list(l3-l2)
c=list(l4-l3)
d=list(l5-l4)
l1=list(l1)
d5['3']=l1
d5['8']=a
d5['13']=b
d5['18']=c
d5['23']=d
##4,9,14,19,24
l1=list(r5['A_follower_cnt_1'])
l2=list(r5['A_follower_cnt_2'])
l3=list(r5['A_follower_cnt_3'])
l4=list(r5['A_follower_cnt_4'])
l5=list(r5['A_follower_cnt_5'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
max_4=getmax(l4)
max_5=getmax(l5)
d5['4']=max_1
d5['9']=max_2
d5['14']=max_3
d5['19']=max_4
d5['24']=max_5
##5,10,15,20,25
l1=list(r5['A_voteup_cnt_1'])
l2=list(r5['A_voteup_cnt_2'])
l3=list(r5['A_voteup_cnt_3'])
l4=list(r5['A_voteup_cnt_4'])
l5=list(r5['A_voteup_cnt_5'])
max_1=getmax(l1)
max_2=getmax(l2)
max_3=getmax(l3)
max_4=getmax(l4)
max_5=getmax(l5)
d5['5']=max_1
d5['10']=max_2
d5['15']=max_3
d5['20']=max_4
d5['25']=max_5
##reorder
order+=['21','22','23','24','25']
d5=d5[order]
d5['td1']=list(r5['A_time_1'])
d5['td2']=list(r5['A_time_2'])
d5['td3']=list(r5['A_time_3'])
d5['td4']=list(r5['A_time_4'])
d5['td5']=list(r5['A_time_5'])


d5=d5.drop_duplicates('q_id')
d4=d4.drop_duplicates('q_id')
d3=d3.drop_duplicates('q_id')
d5.to_csv('file/data5.csv', sep=',', header=True, index=False)
d4.to_csv('file/data4.csv', sep=',', header=True, index=False)
d3.to_csv('file/data3.csv', sep=',', header=True, index=False)

