# -*- coding: utf-8 -*-
import pandas as pd

r5=pd.read_csv('r5.csv',encoding='utf-8')

x21=pd.read_csv('data/学习2_base_1207_121602.csv')
x21.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
x22=pd.read_csv('data/学习2_1207_170710.csv')
x22.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
x23=pd.read_csv('data/学习2_1207_220738.csv')
x23.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
x24=pd.read_csv('data/学习2_1208_041839.csv')
x24.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
x25=pd.read_csv('data/学习2_1208_101058.csv')
x25.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)

a2=pd.merge(x21,x22,on='q_id',how='inner',left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
b2=pd.merge(x23,x24,on='q_id',how='inner',left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
c2_=pd.merge(a2,b2,on='q_id',how='inner')
c2=pd.merge(c2_,x25,on='q_id',how='inner')
# print(c2)
# print(c2.columns.values.tolist())
# print(r5.columns.values.tolist())
t=pd.concat([r5,c2],axis=0,join='outer')
t.rename(columns={'A_follower_cnt':'A_follower_cnt_5','A_time':'A_time_5','A_voteup_cnt':'A_voteup_cnt_5','Answer_cnt':'Answer_cnt_5','Q_follower_cnt':'Q_follower_cnt_5','Time':'Time_5','Visit_cnt':'Visit_cnt_5'},inplace=True)
r5=t.drop_duplicates('q_id')
r5.to_csv('file/t5.csv', header=True, index=False)
# print(r5)