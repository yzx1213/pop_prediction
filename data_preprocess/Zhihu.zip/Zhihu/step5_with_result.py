# encoding:utf-8
import pandas as pd 

r1 = pd.read_csv('result/1214_081954.csv')
r2 = pd.read_csv('result/1214_083446.csv')
r3 = pd.read_csv('result/1214_085456.csv')
r4 = pd.read_csv('result/1214_100849.csv')

d = pd.concat([r1,r2,r3,r4],axis=0,join='outer')

d.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
d=d.drop_duplicates('q_id')

d3=pd.read_csv('file/alldata3.csv')
d4=pd.read_csv('file/alldata4.csv')
d5=pd.read_csv('file/data5.csv')

f3=pd.merge(d3,d,on='q_id',how='inner')
f3=f3.drop_duplicates('q_id')

f4=pd.merge(d4,d,on='q_id',how='inner')
f4=f4.drop_duplicates('q_id')

f5=pd.merge(d5,d,on='q_id',how='inner')
f5=f5.drop_duplicates('q_id')


f5.to_csv('file/final5.csv', header=True, index=False)
f4.to_csv('file/final4.csv', header=True, index=False)
f3.to_csv('file/final3.csv', header=True, index=False)