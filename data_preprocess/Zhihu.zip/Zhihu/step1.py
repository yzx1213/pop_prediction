# -*- coding: utf-8 -*-
import pandas as pd
import numpy as np
import time
import os



basepath='data/base'
dyna1path='data/dynamic1'
dyna2path='data/dynamic2'
dyna3path='data/dynamic3'
dyna4path='data/dynamic4'


basedata=[]
d1data=[]
d2data=[]
d3data=[]
d4data=[]
nameb=[]
name1=[]
name2=[]
name3=[]
name4=[]
#cols_to_use = ['q_id', 'Time', 'Visit_cnt', 'Answer_cnt', 'Q_follower_cnt', 'A_follower_cnt', 'A_voteup_cnt', 'A_time', 'Tag']
for i in os.listdir(r'D:\2专业\机器学习\dataprocess\data\base'):
    path = os.path.join(basepath,i)
    temp=i.split('_')[0]
    nameb.append(temp)
    
    #data = pd.read_csv(path, usecols= cols_to_use)
    data=pd.read_csv(path)
    data.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
    basedata.append(data)
#print(basedata[0].columns.values.tolist())    
#cols_to_use = ['q_id', 'Time', 'Visit_cnt', 'Answer_cnt', 'Q_follower_cnt', 'A_follower_cnt', 'A_voteup_cnt', 'A_time']
for i in os.listdir(r'D:\2专业\机器学习\dataprocess\data\dynamic1'):
    path = os.path.join(dyna1path,i)
    temp=i.split('_')[0]
    name1.append(temp)
    data=pd.read_csv(path)
    data.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
    d1data.append(data)
    
for i in os.listdir(r'D:\2专业\机器学习\dataprocess\data\dynamic2'):
    path = os.path.join(dyna2path,i)
    temp=i.split('_')[0]
    name2.append(temp)
    data=pd.read_csv(path)
    data.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
    d2data.append(data)
    
for i in os.listdir(r'D:\2专业\机器学习\dataprocess\data\dynamic3'):
    path = os.path.join(dyna3path,i)
    temp=i.split('_')[0]
    name3.append(temp)
    data=pd.read_csv(path)
    data.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
    d3data.append(data)
    
for i in os.listdir(r'D:\2专业\机器学习\dataprocess\data\dynamic4'):
    path = os.path.join(dyna4path,i)
    temp=i.split('_')[0]
    name4.append(temp)
    data=pd.read_csv(path)
    data.rename(columns={'Unnamed: 0':'q_id'}, inplace=True)
    d4data.append(data)
    
d2data[4] = d2data[4].drop(columns=['Unnamed: 8', 'Unnamed: 9', 'Unnamed: 10', 'Unnamed: 11'])

#只有三轮的数据
r3=[]
#生活 纠错
temp=basedata[10]
basedata[10]=d2data[9]
d2data[9]=temp
#合并一轮二轮
m12=pd.merge(basedata[10], d1data[11], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
#合并第三轮
m=pd.merge(m12,d2data[9],on='q_id',how='inner')
r3.append(m)

#职业发展
m12=pd.merge(basedata[13], d1data[14], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,d2data[12],on='q_id',how='inner')
r3.append(m)

#恋爱
m12=pd.merge(basedata[7], d1data[7], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,d2data[6],on='q_id',how='inner')
r3.append(m)


#有五轮的强者
r5=[]
m12=pd.merge(basedata[4], d1data[4], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[4], d3data[4], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m_=pd.merge(m12,m34,on='q_id',how='inner')
m=pd.merge(m_,d4data[1],on='q_id',how='inner')
r5.append(m)

#大学
m12=pd.merge(basedata[2], d1data[2], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[2], d3data[2], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m_=pd.merge(m12,m34,on='q_id',how='inner')
m=pd.merge(m_,d4data[0],on='q_id',how='inner')
r5.append(m)

#电影
m12=pd.merge(basedata[11], d1data[12], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[10], d3data[8], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m_=pd.merge(m12,m34,on='q_id',how='inner')
m=pd.merge(m_,d4data[4],on='q_id',how='inner')
r5.append(m)

#心理学
m12=pd.merge(basedata[6], d1data[6], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[5], d3data[5], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m_=pd.merge(m12,m34,on='q_id',how='inner')
m=pd.merge(m_,d4data[2],on='q_id',how='inner')
r5.append(m)

'''
#处理演艺圈
m12=pd.merge(basedata[9], d1data[9], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[8], d3data[7], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m_=pd.merge(m12,m34,on='q_id',how='inner')
m=pd.merge(m_,d4data[3],on='q_id',how='inner')
r5.append(m)
'''

#四轮的小可爱们
r4=[]
#如何X
m12=pd.merge(basedata[3], d1data[3], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[3], d3data[3], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,m34,on='q_id',how='inner')
r4.append(m)
#健康
m12=pd.merge(basedata[1], d1data[1], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[1], d3data[1], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,m34,on='q_id',how='inner')
r4.append(m)
#互联网
m12=pd.merge(basedata[0], d1data[0], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[0], d3data[0], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,m34,on='q_id',how='inner')
r4.append(m)
#经济
m12=pd.merge(basedata[12], d1data[13], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[11], d3data[9], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,m34,on='q_id',how='inner')
r4.append(m)
#情感
m12=pd.merge(basedata[8], d1data[8], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_1', '_2'), copy=True, indicator=False, validate=None)
m34=pd.merge(d2data[7], d3data[6], on='q_id', how='inner', left_on=None, right_on=None, left_index=False, right_index=False, sort=False, suffixes=('_3', '_4'), copy=True, indicator=False, validate=None)
m=pd.merge(m12,m34,on='q_id',how='inner')
r4.append(m)


#处理学习~~
order=r3[1].columns.values.tolist()
r3[0]=r3[1][order]

R3=pd.concat([r3[0],r3[1],r3[2]],axis=0,join='outer')
R3.to_csv('file/r3.csv', sep=',', header=True, index=False)
R4=pd.concat([r4[0],r4[1],r4[2],r4[3],r4[4]],axis=0,join='outer')
R4.to_csv('file/r4.csv', sep=',', header=True, index=False)
R5=pd.concat([r5[0],r5[1],r5[2],r5[3]],axis=0,join='outer')
R5.to_csv('file/r5.csv', sep=',', header=True, index=False)
# print(R5.columns.values.tolist())
