import pandas as pd

r3=pd.read_csv('file/data3.csv')
r4=pd.read_csv('file/data4.csv')
r5=pd.read_csv('file/data5.csv')

order3=r3.columns.values.tolist()
order4=r4.columns.values.tolist()

t3=r4[order3]
p3=r5[order3]

p4=r5[order4]

r3=pd.concat([r3,t3,p3],axis=0,join='outer')
r4=pd.concat([r4,p4],axis=0,join='outer')

r5=r5.drop_duplicates('q_id')
r4=r4.drop_duplicates('q_id')
r3=r3.drop_duplicates('q_id')

r3.to_csv('file/alldata3.csv', header=True, index=False)
r4.to_csv('file/alldata4.csv', header=True, index=False)


