
###sexist some wrong data
import pandas as pd
data=pd.read_csv('file/final.csv')
#print(data)

data=data[~(data['c7'].map(lambda d: d<0))]
data=data[~(data['c13'].map(lambda d: d<0))]
data=data[~(data['c19'].map(lambda d: d<0))]
#print(data)

data.to_csv('final.csv',sep=',',header=True,index=None)