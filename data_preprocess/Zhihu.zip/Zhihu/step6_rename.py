import pandas as pd

data=pd.read_csv('file/final4.csv')
view1=data['Visit_cnt']
view0=data['1']
diff=view1-view0
diff=diff.tolist()
data['difference']=diff


#select
dict_name={}
name0=['1','2','3','4','5','td1','6','7','8','9','10','td2','11','12','13','14','15','td3','16','17','18','19','20','td4']
name1=['c1','c2','c3','c4','c5','c6','c7','c8','c9','c10','c11','c12','c13','c14','c15','c16','c17','c18','c19','c20','c21','c22','c23','c24']
for i in range(len(name0)):
    dict_name[name0[i]]=name1[i]
data.rename(columns=dict_name,inplace=True)
print(dict_name)
order=['q_id']+name1+['difference']
writer=data[order]
writer.to_csv('file/final.csv',sep=',',header=True,index=None)