# -*- coding: utf-8 -*-
#########user_profile1,2 and  retweet_content can be download from the link in our report

import time
import heapq

# 将时间格式转换成unix时间戳
def unix_time(time_p):
    time_p = time.strptime(time_p, '%Y-%m-%d-%H:%M:%S')
    time_p = time.mktime(time_p)
    return int(time_p)


time_need = 60 * 60 * 24

#dict_id = {}  # 通过昵称得到用户的id（用在retweet）
dict_fo = {}  # 通过id得到用户的粉丝数
dict_bi = {}  # 通过id得到用户的互关数


def mkdict(file):
    i = j = 0
    name = []
    bi = []
    follow = []
    id_ = []
    for n in file:
        j += 1
        if j < 16:  # 跳过前15行
            continue
        else:
            i += 1
            i = i % 15
            temp=n.split('\n')[0]
            if i == 9:
                name.append(temp)
            elif i == 2:
                bi.append(temp)
            elif i == 5:
                follow.append(temp)
            elif i == 1:
                id_.append(temp)
            else:
                continue
    for i in range(0, len(name)):
        #dict_id[name[i]] = id_[i]
        dict_fo[id_[i]] = follow[i]
        dict_bi[id_[i]] = bi[i]


# 判断行的性质
def judgeline(n):
    if len(n.split()) == 0:
        return 0  # 空行
    elif n[0] == '@':
        return 2  # @行
    elif n[0] == 'r':
        return 3  # 转发路径行
    elif n[0] == 'l':
        return 5  # link 行
    elif len(n.split()) == 4 and len(n.split()[2]) == 19:
        return 1  # new message行
    elif len(n.split()) == 3 and len(n.split()[1]) == 19:
        return 4  # 转发信息行
    else:
        return -1


file = open('user_profile1.txt', 'r', encoding='gbk')
mkdict(file)
file.close()
file = open('user_profile2.txt', 'r', encoding='gbk')
mkdict(file)
file.close()


print("##################################dictionary is done")

fin = open('Retweet_Content.txt', 'r', encoding='gbk')
finfo = open('info.txt', 'w')
fcnt=open('count.txt','w')
fbi=open('bi.txt','w')
ffo=open('fo.txt','w')
ftime=open('time.txt','w')
finfo.write("ori_id;ori_time;total_cnt;ori_follow;ori_bi;\n")
fbi.write("ori_id;bi1;bi2;bi3;bi4;bi5;bi6;bi7;bi8;bi9;bi10;\n")
ffo.write("ori_id;fo1;fo2;fo3;fo4;fo5;fo6;fo7;fo8;fo9;fo10;\n")
ftime.write("ori_id;t1;t2;t3;t4;t5;t6;t7;t8;t9;t10;\n")

#message = []

count_m = 0

now = fin.readline()  # 读第一行
while judgeline(now) == 1:  # 新的一条始发微博     #对于微博的循环
    path=""
    wrong_cnt=0
    count_r = 0
    tmp = now.split()
    root_id = tmp[1]
    # if root_id in dict_fo.keys():
    #     cnt+=1
    # else:
    #     # while judgeline(now) != 4 and judgeline(now) != 0 and judgeline(now) != 1:
    #     while judgeline(now) != 1:   #如果没有读到下一个微博，就一直往下读
    #         now = fin.readline()
    #     continue #离开这次的循环
    # origin_follow=dict_fo[tmp[1]]+';' # 原始用户的粉丝数 str  ?????
    # origin_bi=dict_bi[tmp[i]] +";"# 原始用户的互关数 str
    root_time = tmp[2]
    root_time = unix_time(root_time)  # 始发时间，时间戳 int
    id_message = tmp[0]
    now = fin.readline()  # 读第二行
    re_cnt=now.split()[0]  # 在数据集中的转发数 str
    #path=origin_bi+origin_follow+str(root_time)+';'+re_cnt+';'
    path = root_id+';'+ str(root_time) + ';' + re_cnt + ';'
    now = fin.readline()  # 读第三行
    time_path=[]
    bi_path=[]
    follow_path=[]
    while judgeline(now) == 4:  # 判断是否在转发信息行     #对于转发的循环
        tmp = now.split()
        time_re = tmp[1]
        time_re = unix_time(time_re)  # 转发时间
        time_re -= root_time  # 转发的时间差~~
        user_re = tmp[0]  # 转发用户的id
        if user_re not in dict_bi.keys():
            wrong_cnt+=1
            print(user_re)
            print(wrong_cnt)
            now = fin.readline() #文本信息行
            now = fin.readline() #判断下一行
            while judgeline(now) != 4 and judgeline(now) != 0 and judgeline(now) != 1:
                now = fin.readline()
            
            continue
        time_path.append(time_re)
        bi_path.append(dict_bi[user_re])
        follow_path.append(dict_fo[user_re])
        count_r += 1  # 反正这一次的转发读完了
        #path += time_path + bi_path + follow_path + ';'
        now = fin.readline()  # 文本内容行，直接跳过
        now = fin.readline()  # 读取文本后一行 {为下一个retweet信息} {@行} {link行} {空行直接进入下一个微博}

        # if judgeline(now) == 0: #读到空行————————到了下一个微博或者数据集结束
        #     now=fin.readline()
        #     break
        # else: #下面的信息都没有用了 直接读到新的转发或者空行或者
        while judgeline(now) != 4 and judgeline(now) != 0 and judgeline(now) != 1:
            now = fin.readline()
        continue  # 继续对转发的循环，若不是转发则在while处跳出,如果是空行的下一行还是空行那么数据集结束，会在第一个wile处结束循环



    if count_r >= 10 and root_id in dict_fo.keys():
        count_m += 1
        origin_follow=dict_fo[root_id]+';' # 原始用户的粉丝数 str  ?????
        origin_bi=dict_bi[root_id] +";"# 原始用户的互关数 str
        path=str(count_m)+';'+path + origin_follow + origin_bi +'\n'
        finfo.write(path)
        cnt=str(count_r)+','+re_cnt+'\n'
        fcnt.write(cnt)
        #time_path=heapq.nsmallest(10,follow_path)
        idx = list(map(time_path.index, heapq.nsmallest(10, time_path)))
        follow=""
        bi=""
        time_=""
        for i in idx:
            follow+=str(follow_path[i])+';'
            bi+=str(bi_path[i])+';'
            time_ += str(time_path[i])+';'
        fbi.write(root_id+';'+bi+'\n')
        ffo.write(root_id+';'+follow+'\n')
        ftime.write(root_id+';'+time_+'\n')
        print(count_m)

print(count_m)
ftime.close()
ffo.close()
fbi.close()
fcnt.close()
finfo.close()
fin.close()