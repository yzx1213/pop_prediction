import pandas as pd

info=pd.read_table('result/info.txt', sep=';')
fo=pd.read_table('result/fo.txt', sep=';')
time=pd.read_table('result/time.txt', sep=';')
bi=pd.read_table('result/bi.txt', sep=';')
cnt=pd.read_table('result/count.txt', sep=',',header=None)

# cnt.rename(columns={0:'count'},inplace=True)
# cnt.drop([1],inplace=True)
info.drop(['Unnamed: 6','ori_time','total_cnt'],axis=1,inplace=True)
fo.drop(['Unnamed: 11','ori_id'],axis=1,inplace=True)
bi.drop(['Unnamed: 11','ori_id'],axis=1,inplace=True)
time.drop(['Unnamed: 11','ori_id'],axis=1,inplace=True)
count=cnt[0].tolist()
info['count']=count
print(info)
# print(info.columns.values.tolist())
# data=pd.merge(info,time,how='inner',on='ori_id')
data = pd.concat([info,time,fo,bi],axis=1,join='outer',join_axes=[info.index])
print(data.info)

data.to_csv('final.csv',sep=',', header=True, index=False)