import urllib.request
import requests
import json
import pandas as pd
import time
from lxml import etree
from topic import topic_dic
import random
# 进入某一个话题下“等待回答”按时间排序,{}内为话题的id
topic_base_url = "https://www.zhihu.com/api/v4/topics/{}/feeds/timeline_question?include=data%5B%3F(target.type%3Dtopic_sticky_module)%5D.target.data%5B%3F(target.type%3Danswer)%5D.target.content%2Crelationship.is_authorized%2Cis_author%2Cvoting%2Cis_thanked%2Cis_nothelp%3Bdata%5B%3F(target.type%3Dtopic_sticky_module)%5D.target.data%5B%3F(target.type%3Danswer)%5D.target.is_normal%2Ccomment_count%2Cvoteup_count%2Ccontent%2Crelevant_info%2Cexcerpt.author.badge%5B%3F(type%3Dbest_answerer)%5D.topics%3Bdata%5B%3F(target.type%3Dtopic_sticky_module)%5D.target.data%5B%3F(target.type%3Darticle)%5D.target.content%2Cvoteup_count%2Ccomment_count%2Cvoting%2Cauthor.badge%5B%3F(type%3Dbest_answerer)%5D.topics%3Bdata%5B%3F(target.type%3Dtopic_sticky_module)%5D.target.data%5B%3F(target.type%3Dpeople)%5D.target.answer_count%2Carticles_count%2Cgender%2Cfollower_count%2Cis_followed%2Cis_following%2Cbadge%5B%3F(type%3Dbest_answerer)%5D.topics%3Bdata%5B%3F(target.type%3Danswer)%5D.target.annotation_detail%2Ccontent%2Chermes_label%2Cis_labeled%2Crelationship.is_authorized%2Cis_author%2Cvoting%2Cis_thanked%2Cis_nothelp%3Bdata%5B%3F(target.type%3Danswer)%5D.target.author.badge%5B%3F(type%3Dbest_answerer)%5D.topics%3Bdata%5B%3F(target.type%3Darticle)%5D.target.annotation_detail%2Ccontent%2Chermes_label%2Cis_labeled%2Cauthor.badge%5B%3F(type%3Dbest_answerer)%5D.topics%3Bdata%5B%3F(target.type%3Dquestion)%5D.target.annotation_detail%2Ccomment_count%3B&offset=0&limit=20"
#每个话题需要爬取的最新问题数
q_num = 5000
def getQuestionID(name, idx):
    question_id = []
    url = topic_base_url.format(idx)
    while len(question_id) < q_num:
        print('\r{}/{}'.format(len(question_id), q_num), end='')
        req = urllib.request.Request(url.format(idx))
        time.sleep(random.uniform(0.2, 0.5))             
        req.add_header('USER_AGENT',
                   'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)')
        for _ in range(10):
            try:
                with urllib.request.urlopen(req) as resp:
                    resp_str = resp.read()
                    jobj = json.loads(resp_str)
                    questions = jobj['data']
                    for q in questions:
                        q_id = str(q['target']['id'])
                        question_id.append(q_id)
                    break
            except:
                continue
        is_end = jobj['paging']['is_end']
        url = jobj['paging']['next']
        if is_end: break
    return question_id

for key, val in topic_dic.items():
    begin = time.time()
    question_id = getQuestionID(key, val)
    print('\t{} Done. Used time: {}'.format(key, time.time() - begin))
    with open('questions/{}.json'.format(key), 'w') as result_file:
        json.dump(question_id, result_file)
        

