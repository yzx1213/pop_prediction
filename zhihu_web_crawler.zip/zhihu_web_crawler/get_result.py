import urllib.request
import json
import pandas as pd
import time
from datetime import datetime
from lxml import etree
from topic import topic_dic
import random

def getQuestionResult(q_id):
    q_url = "https://www.zhihu.com/question/{}/answers/updated".format(q_id)
    req = urllib.request.Request(q_url)
    time.sleep(random.uniform(0.3,0.5))
    req.add_header('USER_AGENT', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)')
    try:
        with urllib.request.urlopen(req) as resp:
            resp_str = resp.read().decode()
            html = etree.HTML(resp_str)
            info = json.loads(html.xpath('//*[@id="js-initialData"]')[0].text)['initialState']['entities']['questions'][q_id]
            # 获取当前浏览量，当前回答数，当前关注数
            visit_cnt, answer_cnt, q_follower_cnt = info['visitCount'], info['answerCount'], info['followerCount']
            return int(time.time()), visit_cnt, answer_cnt, q_follower_cnt
    except: # 有意外，跳过该问题
        return None

t = time.strftime("%m%d_%H%M%S", time.localtime(time.time()))
f = open("result/{}.csv".format(t), 'a',encoding='utf-8')
f.write(',Time,Visit_cnt,Answer_cnt,Q_follower_cnt\n')
error_id = open("{}.csv".format(t), 'a', encoding='utf-8')
df = pd.read_csv('id.csv', header=None)
question_id=df[0]
cnt = 0
begin = time.time()
for q_id in question_id:
    print('\r {}/{}'.format(cnt, len(question_id)), end='')
    info = getQuestionResult(str(q_id))
    if info is not None:
        log=str(q_id)+','
        for item in info:
            log += (str(item) + ',')
        log = log.strip(',')
        f.write(log +'\n')
    else:
        print('\t Error: {} cannot be visited.'.format(q_id))
        error_id.write(str(q_id)+'\n')
    cnt += 1
print('Done. Used time: {}'.format(time.time() - begin))
f.close()