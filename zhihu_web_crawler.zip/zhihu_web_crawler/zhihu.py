import urllib.request
import json
import pandas as pd
import time
import random
import heapq
from lxml import etree
from topic import topic_dic

#用于获取json信息的函数，仅供测试用
def getkeys(dic,depth = 0):
    print('{')
    depth += 1
    for key, val in dic.items():
        if type(val) == dict:
            print('\t'*depth+key,end=': ')
            getkeys(val,depth)
        else:
            print('\t'*depth+key,end=',\n')
    print('\t' * (depth - 1) + '}')
    
def getQuestionInfo(q_id, get_tag=False):
    #--------------------------------------通过访问html获取的信息------------------------------------------------------
    q_url = "https://www.zhihu.com/question/{}/answers/updated".format(q_id)
    req = urllib.request.Request(q_url)
    time.sleep(random.uniform(0.2, 0.5))
    req.add_header('USER_AGENT', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)')
    try:
        with urllib.request.urlopen(req,timeout=0.5) as resp:
            resp_str = resp.read().decode()
            html = etree.HTML(resp_str)
            info = json.loads(html.xpath('//*[@id="js-initialData"]')[0].text)['initialState']['entities']['questions'][q_id]
            # 获取当前浏览量，当前回答数，当前关注数
            visit_cnt, answer_cnt, q_follower_cnt = info['visitCount'], info['answerCount'], info['followerCount']
    except:  # 有意外，跳过该问题
        return None
    #--------------------------------------借助api获取的信息------------------------------------------------------------
    q_url = "https://www.zhihu.com/api/v4/questions/{}/answers?include=data%5B*%5D.is_normal%2Cadmin_closed_comment%2Creward_info%2Cis_collapsed%2Cannotation_action%2Cannotation_detail%2Ccollapse_reason%2Cis_sticky%2Ccollapsed_by%2Csuggest_edit%2Ccomment_count%2Ccan_comment%2Ccontent%2Ceditable_content%2Cvoteup_count%2Creshipment_settings%2Ccomment_permission%2Ccreated_time%2Cupdated_time%2Creview_info%2Crelevant_info%2Cquestion%2Cexcerpt%2Crelationship.is_authorized%2Cis_author%2Cvoting%2Cis_thanked%2Cis_nothelp%2Cis_labeled%2Cis_recognized%2Cpaid_info%2Cpaid_info_content%3Bdata%5B*%5D.mark_infos%5B*%5D.url%3Bdata%5B*%5D.author.follower_count%2Cbadge%5B*%5D.topics&offset=0&limit=20&sort_by=updated".format(q_id)
    req = urllib.request.Request(q_url)
    time.sleep(random.uniform(0.2, 0.5))
    req.add_header('USER_AGENT', 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1)')
    try:
        with urllib.request.urlopen(req,timeout=0.5) as resp:
            resp_str = resp.read()
            jobj = json.loads(resp_str)
            a_follower_cnt, a_voteup_cnt, a_time = [], [], []  # 最新回答者的粉丝数，最新回答者的更新时间
        if answer_cnt > 5:# 大于5条回答，取最新5个回答的时间，最近20个回答者粉丝数最多的五个回答者（的粉丝数）
            for i in range(5):
                a_time.append(jobj['data'][i]['updated_time'])
            for obj in jobj['data']:
                a_follower_cnt.append(obj['author']['follower_count'])
                a_voteup_cnt.append(obj['voteup_count'])
            a_follower_cnt = heapq.nlargest(5, a_follower_cnt)
            a_voteup_cnt = heapq.nlargest(5, a_voteup_cnt)

        elif answer_cnt > 0:  #1到5条，取所有回答的信息
            for i in range(answer_cnt):
                a_follower_cnt.append(jobj['data'][i]['author']['follower_count'])
                a_voteup_cnt.append(jobj['data'][i]['voteup_count'])
                a_time.append(jobj['data'][i]['updated_time'])
    except:  # 有意外，跳过该问题
        return None

    if get_tag:  # 第一次获取问题信息,把标签传回去
        return int(time.time()), visit_cnt, answer_cnt, q_follower_cnt, a_follower_cnt, a_voteup_cnt, a_time, [x['name'] for x in info['topics']]
    else:  # 之后省略标签信息
        return int(time.time()), visit_cnt, answer_cnt, q_follower_cnt, a_follower_cnt, a_voteup_cnt, a_time
#----------------------------------------第一次获取信息，需要tag-------------------------------------------------
for key, val in topic_dic.items():
    t = time.strftime("%m%d_%H%M%S", time.localtime(time.time()))
    f = open("dynamic_data/{}_base_{}.csv".format(key, t), 'a',encoding='utf-8')
    f.write(',Time,Visit_cnt,Answer_cnt,Q_follower_cnt,A_follower_cnt,A_voteup_cnt,A_time,Tag\n')
    with open('questions/{}.json'.format(key), 'r') as result_file:
        question_id = json.load(result_file)
    cnt = 0
    begin = time.time()
    for q_id in question_id:
        print('\r{}: {}/{}'.format(key, cnt, len(question_id)), end='')
        info = getQuestionInfo(q_id, get_tag=True)
        if info is not None:
            log=q_id+','
            for item in info:
                if type(item) == list:
                    log += ('"' + str(item) + '"' + ',')
                else:
                    log += (str(item) + ',')
            log = log.strip(',')
            f.write(log +'\n')
        else:
            print('\t Error: {} cannot be visited.'.format(q_id))
        cnt += 1
    print('\t{} Done. Used time: {}'.format(key, time.time() - begin))
    f.close()
    
#----------------------------------------动态获取信息，不需要tag-------------------------------------------------

for key, val in topic_dic.items():
    t = time.strftime("%m%d_%H%M%S", time.localtime(time.time()))
    f = open("dynamic_data/{}_{}.csv".format(key, t), 'a',encoding='utf-8')
    f.write(',Time,Visit_cnt,Answer_cnt,Q_follower_cnt,A_follower_cnt,A_voteup_cnt,A_time\n')
    with open('questions/{}.json'.format(key), 'r') as result_file:
        question_id = json.load(result_file)
    cnt = 0
    begin = time.time()
    for q_id in question_id:
        print('\r{}: {}/{}'.format(key, cnt, len(question_id)), end='')
        info = getQuestionInfo(q_id, get_tag=False)
        if info is not None:
            log=q_id+','
            for item in info:
                if type(item) == list:
                    log += ('"' + str(item) + '"' + ',')
                else:
                    log += (str(item) + ',')
            log = log.strip(',')
            f.write(log +'\n')
        else:
            print('\t Error: {} cannot be visited.'.format(q_id))
        cnt += 1
    print('\t{} Done. Used time: {}'.format(key, time.time() - begin))
    f.close()
